import React, { useState } from 'react';
import { BookOpen, Brain, Grid, Languages, ChevronRight, CheckCircle2, XCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const hiragana = [
  { jp: 'あ', ro: 'a' }, { jp: 'い', ro: 'i' }, { jp: 'う', ro: 'u' }, { jp: 'え', ro: 'e' }, { jp: 'お', ro: 'o' },
  { jp: 'か', ro: 'ka' }, { jp: 'き', ro: 'ki' }, { jp: 'く', ro: 'ku' }, { jp: 'け', ro: 'ke' }, { jp: 'こ', ro: 'ko' },
  { jp: 'さ', ro: 'sa' }, { jp: 'し', ro: 'shi' }, { jp: 'す', ro: 'su' }, { jp: 'せ', ro: 'se' }, { jp: 'そ', ro: 'so' },
];

const katakana = [
  { jp: 'ア', ro: 'a' }, { jp: 'イ', ro: 'i' }, { jp: 'ウ', ro: 'u' }, { jp: 'エ', ro: 'e' }, { jp: 'オ', ro: 'o' },
  { jp: 'カ', ro: 'ka' }, { jp: 'キ', ro: 'ki' }, { jp: 'ク', ro: 'ku' }, { jp: 'ケ', ro: 'ke' }, { jp: 'コ', ro: 'ko' },
  { jp: 'サ', ro: 'sa' }, { jp: 'シ', ro: 'shi' }, { jp: 'ス', ro: 'su' }, { jp: 'セ', ro: 'se' }, { jp: 'ソ', ro: 'so' },
];

const kanji = [
  { jp: '日', ro: 'hi/nichi', mean: 'Matahari/Hari' },
  { jp: '月', ro: 'tsuki/getsu', mean: 'Bulan' },
  { jp: '火', ro: 'hi/ka', mean: 'Api' },
  { jp: '水', ro: 'mizu/sui', mean: 'Air' },
  { jp: '木', ro: 'ki/moku', mean: 'Pohon' },
];

const quizData = [
  { q: 'Apa arti dari "Konnichiwa"?', a: ['Selamat Pagi', 'Selamat Siang', 'Selamat Malam', 'Terima Kasih'], correct: 1 },
  { q: 'Bagaimana cara menulis "A" dalam Hiragana?', a: ['い', 'う', 'あ', 'え'], correct: 2 },
  { q: 'Apa arti kanji "水"?', a: ['Api', 'Air', 'Tanah', 'Kayu'], correct: 1 },
];

function App() {
  const [activeTab, setActiveTab] = useState('learn');
  const [subTab, setSubTab] = useState('hiragana');
  const [quizIndex, setQuizIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);

  const handleQuizAnswer = (idx) => {
    if (idx === quizData[quizIndex].correct) setScore(score + 1);
    if (quizIndex + 1 < quizData.length) {
      setQuizIndex(quizIndex + 1);
    } else {
      setShowResult(true);
    }
  };

  const resetQuiz = () => {
    setQuizIndex(0);
    setScore(0);
    setShowResult(false);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans">
      {/* Header */}
      <nav className="bg-white border-b sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-red-500 p-2 rounded-lg">
              <Languages className="text-white w-6 h-6" />
            </div>
            <span className="font-bold text-xl tracking-tight">NihonGo!</span>
          </div>
          <div className="flex gap-6">
            <button onClick={() => setActiveTab('learn')} className={`flex items-center gap-2 font-medium ${activeTab === 'learn' ? 'text-red-500' : 'text-slate-500 hover:text-slate-800'}`}>
              <BookOpen className="w-5 h-5" /> Belajar
            </button>
            <button onClick={() => setActiveTab('quiz')} className={`flex items-center gap-2 font-medium ${activeTab === 'quiz' ? 'text-red-500' : 'text-slate-500 hover:text-slate-800'}`}>
              <Brain className="w-5 h-5" /> Kuis
            </button>
          </div>
        </div>
      </nav>

      <main className="max-w-5xl mx-auto px-4 py-8">
        <AnimatePresence mode="wait">
          {activeTab === 'learn' ? (
            <motion.div key="learn" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
              <div className="flex gap-2 mb-8 bg-white p-1 rounded-xl border w-fit">
                {['hiragana', 'katakana', 'kanji'].map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setSubTab(tab)}
                    className={`px-6 py-2 rounded-lg capitalize transition-all ${subTab === tab ? 'bg-red-500 text-white shadow-md' : 'text-slate-600 hover:bg-slate-100'}`}
                  >
                    {tab}
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                {(subTab === 'hiragana' ? hiragana : subTab === 'katakana' ? katakana : kanji).map((item, i) => (
                  <motion.div
                    key={i}
                    whileHover={{ scale: 1.05 }}
                    className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow text-center"
                  >
                    <div className="text-4xl font-bold mb-2 text-slate-800">{item.jp}</div>
                    <div className="text-slate-500 font-medium">{item.ro}</div>
                    {item.mean && <div className="text-xs text-red-500 mt-2 font-semibold uppercase tracking-wider">{item.mean}</div>}
                  </motion.div>
                ))}
              </div>
            </motion.div>
          ) : (
            <motion.div key="quiz" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="max-w-2xl mx-auto">
              {!showResult ? (
                <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-xl">
                  <div className="flex justify-between items-center mb-6">
                    <span className="bg-red-100 text-red-600 px-4 py-1 rounded-full text-sm font-bold">
                      Soal {quizIndex + 1} / {quizData.length}
                    </span>
                  </div>
                  <h2 className="text-2xl font-bold mb-8">{quizData[quizIndex].q}</h2>
                  <div className="grid gap-3">
                    {quizData[quizIndex].a.map((opt, i) => (
                      <button
                        key={i}
                        onClick={() => handleQuizAnswer(i)}
                        className="flex items-center justify-between p-4 rounded-xl border-2 border-slate-100 hover:border-red-200 hover:bg-red-50 transition-all text-left font-medium group"
                      >
                        {opt}
                        <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-red-400" />
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="bg-white p-12 rounded-3xl border border-slate-200 shadow-xl text-center">
                  <div className="inline-flex p-4 bg-green-100 rounded-full mb-6 text-green-600">
                    <CheckCircle2 className="w-12 h-12" />
                  </div>
                  <h2 className="text-3xl font-bold mb-2">Kuis Selesai!</h2>
                  <p className="text-slate-500 mb-8">Kamu menjawab {score} dari {quizData.length} soal dengan benar.</p>
                  <button onClick={resetQuiz} className="bg-red-500 text-white px-8 py-3 rounded-xl font-bold hover:bg-red-600 transition-colors">
                    Coba Lagi
                  </button>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}

export default App;
